import React ,{useEffect, useState} from 'react';
import axios from 'axios';

const Convert=({language,text})=>{
    useEffect(()=>{

      axios.post('https://')

    },[language,text])
return (
    <div>
        
    </div>
)

}

export default Convert;